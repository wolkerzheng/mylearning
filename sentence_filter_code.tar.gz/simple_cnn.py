# -*- coding: utf-8 -*-

from keras import backend as K
from keras.layers import Input,Merge,merge
from keras.layers.core import Dense,Dropout
from keras.layers.embeddings import Embedding
from keras.layers import Conv1D, MaxPooling1D
from keras.layers.recurrent import GRU,LSTM
from keras.layers.wrappers import TimeDistributed,Bidirectional
from keras.layers import GlobalMaxPool1D,GlobalAveragePooling1D
from keras.models import Model
from keras.optimizers import SGD
from keras.utils import to_categorical
from keras.callbacks import EarlyStopping
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, confusion_matrix
import numpy as np
import pickle
# from pre_build_dictionary import word_dictionary
import generate_data as gd
import sys
import load_tieba_w2v
"""
_________________________________________________________________
Layer (type)                 Output Shape              Param #   
=================================================================
input_1 (InputLayer)         (None, 70)                0         
_________________________________________________________________
embedding_1 (Embedding)      (None, 70, 200)           49020200  
_________________________________________________________________
lstm_1 (LSTM)                (None, 100)               120400    
=================================================================
Total params: 49,140,600
Trainable params: 49,140,600
Non-trainable params: 0
_________________________________________________________________
('doc_emb shape is', TensorShape([Dimension(None), Dimension(20), Dimension(100)]))
_________________________________________________________________
__________________________________________________________________________________________________
Layer (type)                    Output Shape         Param #     Connected to                     
==================================================================================================
input_2 (InputLayer)            (None, 20, 70)       0                                            
__________________________________________________________________________________________________
time_distributed_1 (TimeDistrib (None, 20, 100)      49140600    input_2[0][0]                    
__________________________________________________________________________________________________
conv1d_1 (Conv1D)               (None, 19, 16)       3216        time_distributed_1[0][0]         
__________________________________________________________________________________________________
conv1d_2 (Conv1D)               (None, 18, 16)       4816        time_distributed_1[0][0]         
__________________________________________________________________________________________________
conv1d_3 (Conv1D)               (None, 17, 16)       6416        time_distributed_1[0][0]         
__________________________________________________________________________________________________
global_max_pooling1d_1 (GlobalM (None, 16)           0           conv1d_1[0][0]                   
__________________________________________________________________________________________________
global_max_pooling1d_2 (GlobalM (None, 16)           0           conv1d_2[0][0]                   
__________________________________________________________________________________________________
global_max_pooling1d_3 (GlobalM (None, 16)           0           conv1d_3[0][0]                   
__________________________________________________________________________________________________
merge_1 (Merge)                 (None, 48)           0           global_max_pooling1d_1[0][0]     
                                                                 global_max_pooling1d_2[0][0]     
                                                                 global_max_pooling1d_3[0][0]     
__________________________________________________________________________________________________
dense_1 (Dense)                 (None, 32)           1568        merge_1[0][0]                    
__________________________________________________________________________________________________
dense_2 (Dense)                 (None, 1)            33          dense_1[0][0]                    
==================================================================================================
Total params: 49,156,649
Trainable params: 49,156,649
Non-trainable params: 0
LSTM:200:TB
    0.7857
GRU：200：TB
    0.7951
GRU 100 TB
    0.7838
LSTM:100:TB
    0.7896
lstm:200 wiki
    0.7198
gru 200 wiki
    0.7358


"""
MAX_SENTS = 20
MAX_WORDS = 70 #每轮对话中最大的词数量

WORD_EMBED_SIZE = 200
SENT_EMBED_SIZE = 100
DOC_EMBED_SIZE = 100

NUM_CLASSES = 2

BATCH_SIZE = 32
NUM_EPOCHS = 10

max_features = 30000
maxlen = 200  # cut texts after this number of words (among top max_features most common words)
batch_size = 32 #64

def load_wiki_tieba():
	word2id={"PAD": 0}
	with  open('./embedding/wiki.zh.text.vector','rb') as f:
		nums, ran = f.readline().strip().split()
		embedding_weight = np.zeros((int(nums)+1, int(ran)))	#(125605,200)

		# word_dic = dict()
		for i in range(int(nums)):
			line = f.readline().strip().split()
			word, vec = line[0], line[1:]
			vec = list(map(float, vec))
			embedding_weight[i+1, :] = vec
			word2id[word] = i+1
	# word2id['PAD'] = int(nums)
	# embedding_weight[int(nums),:]  = np.zeros(int(ran))
	id2word ={v:k for k,v in word2id.items()}
	global WORD_EMBED_SIZE
	WORD_EMBED_SIZE = 200
	return word2id,embedding_weight
def pad_or_truncate(xs, maxlen):
	    if len(xs) > maxlen:
	        xs = xs[len(xs) - maxlen:]
	    elif len(xs) < maxlen:
	        xs = ["PAD"] * (maxlen - len(xs)) + xs
	    return xs

def datagen(X,Y,batch_size=BATCH_SIZE):
	while True:
		num_recs = X.shape[0]
		indices = np.random.permutation(np.arange(num_recs))
		num_batches = num_recs//batch_size

		for bid in range(num_batches):
			batch_ids = indices[bid*batch_size:(bid+1)*batch_size]
			# xbatfrom sklearn.metrics import accuracy_score, confusion_matrixch = np.zeros((batch_size,MAX_SENTS,MAX_WORDS))
			xbatch = X[batch_ids,:]
			ybatch = Y[batch_ids,:]
			yield xbatch,ybatch

def train(mode='LSTM',w2vec_mode = 'TB',DIM=200,filters=16,kernel_size=[2,3,4],pool_size = 4):
# word2id = {"PAD": 0, "UNK": 1}
    if w2vec_mode == 'TB':
        if DIM == 100:
            word2id,embedding_weight = load_tieba_w2v.loadWord2Vec('./embedding/w2v_model/model/w2v.vector')
        else:
            word2id,embedding_weight = load_tieba_w2v.loadw2c_200dim()
    else:
        word2id,embedding_weight = load_wiki_tieba()
    vocab_size = len(word2id)
    print(type(embedding_weight))	#'numpy.ndarray'
    # print(type(embedding_weight.items()[0]))

    positve_data,pos_y = gd.generateNegitivedata()		#生成带负例的训练数据，label为1的表示为噪音数据
    negtive_data,neg_y = gd.generatePostitivedata()
    print('loaded data...')

	# positive_data = word_dict.pad_transform(positve_data,maxlen)
	# negtive_data = word_dict.pad_transform(negtive_data,maxlen)

    x = np.concatenate((positve_data,negtive_data),axis = 0)
    y = np.concatenate((np.ones((len(positve_data), 1)), np.zeros((len(negtive_data), 1))), axis=0)


    X = np.zeros((len(x),MAX_SENTS,MAX_WORDS))
    for docid,sents in enumerate(x):
        sents = pad_or_truncate(sents,MAX_SENTS)
        for sid, sent in enumerate(sents):
            words = pad_or_truncate(sent.strip().split('/'), MAX_WORDS)
            for wid, word in enumerate(words):
                try:
                    word_id = word2id[word]
                except KeyError:
                    word_id = word2id['<unk>']
                X[docid, sid, wid] = word_id
    # docid2mat[int(rec_id)] = M
    print(X.shape)      #(212399, 20, 70)
    # Y =
    x_tv, x_test, y_tv, y_test = train_test_split(X, y, test_size=0.3)
    x_train,x_val,y_train,y_val = train_test_split(x_tv,y_tv,train_size=0.9)
    print('Build model...')
    print('data is :',len(x),len(y))	#212399

    # docid2mat = {}
    # ftext = open(DOCSIM_TEXTS, "rb")
    global max_features
    max_features = max(max_features,vocab_size)

    sent_in = Input(shape=(MAX_WORDS,), dtype="int32")

    sent_emb = Embedding(input_dim=max_features,
                           output_dim=WORD_EMBED_SIZE,
                           weights=[embedding_weight],
                            mask_zero=True,trainable=True)(sent_in)

    if mode=='GRU':
        sent_enc = GRU(SENT_EMBED_SIZE,return_sequences=False)(sent_emb)
    elif mode=='LSTM':
        sent_enc = LSTM(SENT_EMBED_SIZE,return_sequences=False)(sent_emb)

    # fc1 = Dense(50, activation="relu")(sent_enc)
    # fc2_dropout = Dropout(0.2)(fc1)
    # doc_pred = Dense(1, activation="sigmoid")(fc2_dropout)

    sent_model = Model(inputs=sent_in, outputs=sent_enc)
    sent_model.summary()

    doc_input = Input(shape=(MAX_SENTS, MAX_WORDS), dtype="int32")
    doc_emb = TimeDistributed(sent_model)(doc_input)
    print('doc_emb shape is',doc_emb.shape)
    conv_pool_layers = []
    for k_s in kernel_size:
        conv = Conv1D(filters,
                     k_s,
                     padding='valid',
                     activation='relu',
                     strides=1)(doc_emb)
        maxpool = GlobalMaxPool1D()(conv)
        averpool = GlobalAveragePooling1D()(conv)
        # pool = MaxPooling1D(pool_size=pool_size)(conv)
        conv_pool_layers.append(maxpool)
        conv_pool_layers.append(averpool)
        
    merge_Lyaer = merge(conv_pool_layers, mode='concat')
    dense = Dense(32, activation="relu")(merge_Lyaer)
    doc_pred = Dense(1, activation="sigmoid")(dense)

    model  = Model(inputs=doc_input, outputs=doc_pred)

    model.summary()
    model.compile(loss="binary_crossentropy", optimizer="adam",
                 metrics=["accuracy"])
    early_stopping =EarlyStopping(monitor='val_loss', patience=1)

    hist = model.fit(x_train, y_train,
              batch_size=BATCH_SIZE,
              epochs=NUM_EPOCHS, shuffle=True,
              callbacks=[early_stopping],validation_split=0.2)
    score, acc = model.evaluate(x_test, y_test,batch_size=BATCH_SIZE)


    print('history', hist)
    print('Test score:', score)
    print('Test accuracy:', acc)
    # model.save('simple_gru_cnn.h5')

if __name__ == '__main__':
	if len(sys.argv)>1:
		mode = sys.argv[1]
		w2c  = sys.argv[2]
        DIM = sys.argv[3]
	train(mode=mode,w2vec_mode = w2c,DIM=DIM)