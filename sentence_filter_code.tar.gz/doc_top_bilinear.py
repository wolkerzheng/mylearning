#encoding=utf8
from keras import backend as K
import tensorflow as tf
from keras.layers import Input,merge,Permute,Lambda, Activation,Merge
from keras.layers.core import Dense,Dropout,Reshape,Flatten,RepeatVector
from keras.layers.embeddings import Embedding
from keras.layers.recurrent import GRU
from keras.layers.wrappers import TimeDistributed,Bidirectional
from keras.models import Model
from keras.optimizers import SGD
from keras.utils.np_utils import to_categorical
from keras.callbacks import EarlyStopping
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, confusion_matrix
import mybilinear
# import matplotlib.pyplot as plt
import numpy as np
import pickle
# from pre_build_dictionary import word_dictionary
import generate_data as gd
import sys
import load_tieba_w2v
import neural_tensor_layer
"""
用一个主题对文档的bilinear

_________________________________________________________________
Layer (type)                 Output Shape              Param #   
=================================================================
input_1 (InputLayer)         (None, 70)                0         
_________________________________________________________________
embedding_1 (Embedding)      (None, 70, 200)           49020200  
_________________________________________________________________
gru_1 (GRU)                  (None, 200)               240600    
=================================================================
Total params: 49,260,800
Trainable params: 49,260,800
Non-trainable params: 0
_________________________________________________________________
('topic_enc_r shape is :', TensorShape([Dimension(None), Dimension(1), Dimension(200)]))
('topic,doc shape is :', TensorShape([Dimension(None), Dimension(1), Dimension(200)]), TensorShape([Dimension(None), Dimension(None), Dimension(200)]))
(200, 200)
(?, ?, 200)
('c shape is:', TensorShape([Dimension(None), Dimension(None), Dimension(200)]))
('shape attended is :', TensorShape([Dimension(None), Dimension(200), Dimension(200)]))
______________________________________________________________________________________
Layer (type)                    Output Shape         Param #     Connected to                     
==================================================================================================
input_3 (InputLayer)            (None, 1, 70)        0                                            
__________________________________________________________________________________________________
time_distributed_2 (TimeDistrib (None, 1, 200)       49260800    input_3[0][0]                    
__________________________________________________________________________________________________
input_2 (InputLayer)            (None, 20, 70)       0                                            
__________________________________________________________________________________________________
dense_1 (Dense)                 (None, 1, 200)       40200       time_distributed_2[0][0]         
__________________________________________________________________________________________________
time_distributed_1 (TimeDistrib (None, 20, 200)      49260800    input_2[0][0]                    
__________________________________________________________________________________________________
flatten_1 (Flatten)             (None, 200)          0           dense_1[0][0]                    
__________________________________________________________________________________________________
bidirectional_1 (Bidirectional) (None, 20, 200)      180600      time_distributed_1[0][0]         
__________________________________________________________________________________________________
repeat_vector_1 (RepeatVector)  (None, 20, 200)      0           flatten_1[0][0]                  
__________________________________________________________________________________________________
neural_tensor_layer_1 (NeuralTe (None, 20)           808200      bidirectional_1[0][0]            
                                                                 repeat_vector_1[0][0]            
__________________________________________________________________________________________________
dense_2 (Dense)                 (None, 20)           420         neural_tensor_layer_1[0][0]      
__________________________________________________________________________________________________
activation_1 (Activation)       (None, 20)           0           dense_2[0][0]                    
======================================================================

"""
MAX_SENTS = 20 #每轮对话最大的句子数目
MAX_WORDS = 70 #每句话中最大的词数量

WORD_EMBED_SIZE = 200
SENT_EMBED_SIZE = 200
DOC_EMBED_SIZE = 100

NUM_CLASSES = 2

BATCH_SIZE = 64
NUM_EPOCHS = 10

max_features = 30000
maxlen = 200  # cut texts after this number of words (among top max_features most common words)
batch_size = 64 #64

w2vec_mode = 'TB'
DIM = 200
def load_wiki_tieba():
    word2id={"PAD": 0}
    with  open('./embedding/wiki.zh.text.vector','rb') as f:
        nums, ran = f.readline().strip().split()
        embedding_weight = np.zeros((int(nums)+1, int(ran)))    #(125605,200)

        # word_dic = dict()
        for i in range(int(nums)):
            line = f.readline().strip().split()
            word, vec = line[0], line[1:]
            vec = list(map(float, vec))
            embedding_weight[i+1, :] = vec
            word2id[word] = i+1
    # word2id['PAD'] = int(nums)
    # embedding_weight[int(nums),:]  = np.zeros(int(ran))
    id2word ={v:k for k,v in word2id.items()}
    global WORD_EMBED_SIZE
    WORD_EMBED_SIZE = 200
    return word2id,embedding_weight

# word2id = {"PAD": 0, "UNK": 1}
if w2vec_mode == 'TB':
        if DIM == 100:
            word2id,embedding_weight = load_tieba_w2v.loadWord2Vec('./embedding/w2v_model/model/w2v.vector')
        else:
            word2id,embedding_weight = load_tieba_w2v.loadw2c_200dim()
else:
    word2id,embedding_weight = load_wiki_tieba()
print(type(embedding_weight))   #'numpy.ndarray'
# print(type(embedding_weight.items()[0]))


vocab_size = len(word2id)
print(type(embedding_weight))   #'numpy.ndarray'
# print(type(embedding_weight.items()[0]))

def pad_or_truncate(xs, maxlen,wordLevel=True):
    if len(xs) > maxlen:
        if wordLevel:
                xs = xs[len(xs) - maxlen:]
        else:
                xs = xs[0:maxlen]
    elif len(xs) < maxlen:
        if wordLevel:
                xs = ["PAD"] * (maxlen - len(xs)) + xs
        else:
                xs = xs+["PAD"]*(maxlen-len(xs))
    return xs

def datagen(X,Y,batch_size=BATCH_SIZE):
        while True:
                num_recs = X.shape[0]
                indices = np.random.permutation(np.arange(num_recs))
                num_batches = num_recs//batch_size

                for bid in range(num_batches):
                        batch_ids = indices[bid*batch_size:(bid+1)*batch_size]
                        xbatch = X[batch_ids,:]
                        ybatch = Y[batch_ids,:]
                        yield xbatch,ybatch
def pady(y, maxlen=MAX_SENTS):
        if len(y)>maxlen:
                y = y[0:maxlen]
        else:
                y = y + [0]*(maxlen-len(y))
        return y

x,y = gd.generateNegitivedata()

y = list(map(pady,y))

print('loaded data...')


x,y = np.array(x),np.array(y)
print(y.shape)  #(109324,20)
print(type(y))

X = np.zeros((len(x),MAX_SENTS,MAX_WORDS))
for docid,sents in enumerate(x):
        sents = pad_or_truncate(sents,MAX_SENTS,False)
        for sid, sent in enumerate(sents):
                words = pad_or_truncate(sent.strip().split('/'), MAX_WORDS)
                for wid, word in enumerate(words):
                        try:
                                word_id = word2id[word]
                        except KeyError:
                                word_id = word2id['<unk>']
                        X[docid, sid, wid] = word_id
# docid2mat[int(rec_id)] = M
print(X.shape)          #(109324, 20, 70)
# Y =
# x_tv, x_test, y_tv, y_test = train_test_split(X, y, test_size=0.2)
# x_train,x_val,y_train,y_val = train_test_split(x_tv,y_tv,train_size=0.9)

x_train,x_test,y_train,y_test = train_test_split(X, y, test_size=0.2)

# print(x_train.shape,x_train[:,0,:].shape)     #((87459, 20, 70), (87459, 70))

x_train_right = x_train[:,0,:].reshape(len(x_train),1,MAX_WORDS)

x_test_right = x_test[:,0,:].reshape(len(x_test),1,MAX_WORDS)
print(x_train_right.shape,x_train.shape)                #((87459,1, 70)(87459, 20, 70))
print('Build model...')
print('data is :',len(x),len(y))        #212399

# docid2mat = {}
# ftext = open(DOCSIM_TEXTS, "rb")

max_features = max(max_features,vocab_size)

sent_in = Input(shape=(MAX_WORDS,), dtype="int32")

sent_emb = Embedding(input_dim=max_features,
                       output_dim=WORD_EMBED_SIZE,
                       weights=[embedding_weight],
                       # trainable=True)(sent_in)
                        mask_zero=True,trainable=True)(sent_in)

sent_enc = GRU(SENT_EMBED_SIZE,return_sequences=False)(sent_emb)

sent_model = Model(sent_in,sent_enc)
sent_model.summary()

doc_in_l = Input(shape=(MAX_SENTS, MAX_WORDS), dtype="int32")

doc_emb_l = TimeDistributed(sent_model)(doc_in_l)

doc_enc_l = Bidirectional(GRU(DOC_EMBED_SIZE,
                              return_sequences=True))(doc_emb_l)


topic_in_r = Input(shape=(1,MAX_WORDS),dtype="int32")
topic_emb_r = TimeDistributed(sent_model)(topic_in_r)
topic_enc_r = Dense(SENT_EMBED_SIZE, activation="relu")(topic_emb_r)

topic_enc_r = Flatten()(topic_enc_r)
topic_enc_r = RepeatVector(MAX_SENTS)(topic_enc_r)
def my_dot(x,MAX_SENTS=20):
        """
            attention_dot
        """
        d_btf, t_bf = x
        #res = K.batch_dot(d_btf, tf.expand_dims(t_bf, -1),(3, 2))
        res = K.batch_dot(d_btf,t_bf)
        return K.reshape(res, [-1, MAX_SENTS])
print('topic,doc shape is :',topic_enc_r.get_shape(),doc_enc_l.get_shape())

#('topic,doc shape is :', TensorShape([Dimension(None), Dimension(200)]), TensorShape([Dimension(None), Dimension(None), Dimension(200)]))

attended = mybilinear.CustomBiLinear()([doc_enc_l,topic_enc_r])
   #TensorShape([Dimension(None), Dimension(200),1])
# attended = neural_tensor_layer.NeuralTensorLayer(output_dim=20, input_dim=200)([doc_enc_l,topic_enc_r])
print('shape attended is :',attended.get_shape())
dd = Dense(MAX_SENTS)(attended)
match = Activation('softmax')(dd)


# dense_1 = Dense(MAX_SENTS,activation='relu')(attended)


# attention_dt = Activation(activation='softmax',name='softmax')(dense_1)

model = Model(inputs=[doc_in_l,topic_in_r], outputs=match)
model.summary()

model.compile(loss="categorical_crossentropy", optimizer="adam",metrics=["accuracy"])
early_stopping =EarlyStopping(monitor='val_loss', patience=1)


hist = model.fit([x_train,x_train_right], y_train,
          batch_size=BATCH_SIZE,
          epochs=NUM_EPOCHS, shuffle=True,
          callbacks=[early_stopping],
          validation_split = 0.1)
score, acc = model.evaluate([x_test,x_test_right], y_test,batch_size=BATCH_SIZE)


print('history', hist)
print('Test score:', score)
print('Test accuracy:', acc)
model.save('docToTopicAtten1.h5')
# plt.subplot(211)
# plt.title("accuracy")
# plt.plot(hist.history["acc"], color="r", label="train")
# plt.plot(hist.history["val_acc"], color="b", label="val")
# plt.legend(loc="best")
#
# plt.subplot(212)
# plt.title("loss")
# plt.plot(hist.history["loss"], color="r", label="train")
# plt.plot(hist.history["val_loss"], color="b", label="val")
# plt.legend(loc="best")
#
# plt.tight_layout()
# plt.show()
