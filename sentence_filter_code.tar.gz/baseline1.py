#encoding=utf8
import numpy as np 
import sys
import generate_data as gdata
from  sklearn.feature_extraction.text import CountVectorizer
from sklearn.model_selection import train_test_split
from sklearn import linear_model
from sklearn.metrics import accuracy_score

import re
import codecs
np.random.seed(100)


def getCorpus():

    positve_data,pos_y = gdata.generateNegitivedata()		#生成带负例的训练数据，label为1的表示为噪音数据
    negtive_data,neg_y = gdata.generatePostitivedata()
    print('loaded data...')

    # positive_data = word_dict.pad_transform(positve_data,maxlen)
    # negtive_data = word_dict.pad_transform(negtive_data,maxlen)

    x = np.concatenate((positve_data,negtive_data),axis = 0)
    y = np.concatenate((np.ones((len(positve_data), 1)), np.zeros((len(negtive_data), 1))), axis=0)
    # print(x.shape)
    return x,y
def n_grammodel(train_data,min_n_gram=1,max_n_grad=3):

    count_vect = CountVectorizer(min_df=3, ngram_range=(min_n_gram,max_n_grad))
    X_train_counts = count_vect.fit_transform(train_data)
    print(X_train_counts.shape)
    return  count_vect

def loadStopWords(filename='./constant/stopwords.cn.txt'):

    with codecs.open(filename,'r',encoding='utf8') as f:
        stopwords = f.readlines()
        stopwords = [ w.strip() for w in stopwords ]
    return set(stopwords)

def process_corpus(x):
    stopwords = loadStopWords()
    train_data = []
    for sents in x:
        sent = []
        # print(sents)
        for ss in sents:
            sent.append(ss.strip().split('/'))
        # print(sent)
        ww = []
        for words in sent:

            ww.extend([w for w in words if w not in stopwords and w!=''])
        train_data.append(' '.join(ww))
        # break
    # print(train_data)
    return np.array(train_data)

def main(min_n_gram=1,max_n_grad=2):
    x,y = getCorpus()
    X = process_corpus(x)
    print(X[0:1])
    print(X.shape)
    x_tv, x_test, y_tv, y_test = train_test_split(X, y, test_size=0.2)
    x_train,x_val,y_train,y_val = train_test_split(x_tv,y_tv,train_size=0.9)
    # n_grammodel(x_train,min_n_gram=1,max_n_grad=3)
    count_vect = CountVectorizer(min_df=10, ngram_range=(min_n_gram,max_n_grad))
    count_vect.fit(X)
    X_train_counts = count_vect.transform(x_train).toarray()
    x_val_count = count_vect.transform(x_val).toarray()
    x_test_cout = count_vect.transform(x_test)
    # print(X_train_counts.shape)
    return  count_vect

    logreg = linear_model.LogisticRegression(C=1e5)
    logreg.fit(X_train_counts, y_train,validation_data=[x_val_count,y_val])
    y_pred = logreg.predict(x_test_cout)
    accuracy_score(x_test_cout,y_pred)

def test():
    import jieba
    """
    output:
    ['他 用 报话机 向 上级 呼喊 ： “ 为了 祖国 ， 为了 胜利 ， 向 我 开炮 ！ 向 我 开炮 ！', '记者 ： 你 怎么 会 说出 那 番话 ？', '韦昌进 ： 我 只是 觉得 ， 对准 我 自己 打 ， 才 有 可能 把 上 了 我 哨位 的 这些 敌人 打死 ， 或者 打 下去 。']
    (3, 45)
    [[1 1 0 2 1 1 0 0 0 0 1 1 0 0 0 0 2 1 0 0 0 0 0 0 1 1 0 0 0 1 1 1 1 0 0 0
      0 0 0 0 0 0 0 0 0]
     [0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 1 0 0 0 0 0 0 0 0 1 0 0 0 0 0 0 0
      0 1 1 1 1 0 0 0 0]
     [0 0 1 0 0 0 1 1 1 1 0 0 1 1 1 1 0 0 0 0 1 1 1 1 0 0 1 1 0 0 0 0 0 1 1 1
      1 0 0 0 0 1 1 1 1]]
    """
    data = ["他用报话机向上级呼喊：“为了祖国，为了胜利，向我开炮！向我开炮！",
            "记者：你怎么会说出那番话？",
            "韦昌进：我只是觉得，对准我自己打，才有可能把上了我哨位的这些敌人打死，或者打下去。"]

    data = [" ".join(jieba.lcut(e)) for e in data] # 分词，并用" "连接
    for i in data:
        print(i)
    print(data)
    # print
    vec = CountVectorizer(min_df=1, ngram_range=(1,2))
    x = vec.fit_transform(data)
    print(x.shape)
    print(x.toarray())
if __name__ == '__main__':
    main(2,2)
    # test()
