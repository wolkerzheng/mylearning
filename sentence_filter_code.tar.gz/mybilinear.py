#encoding=utf8
from keras import backend as K
from keras.engine.topology import Layer
#from keras.layers.merge import add,average,concatenate,maximum,multiply
import numpy as np
class CustomBiLinear(Layer):

    """
    Keras layer to compute an attention vector on an incoming matrix
    and a user provided context vector.

    # Input
        enc - 3D Tensor of shape (BATCH_SIZE, MAX_TIMESTEPS, EMBED_SIZE)
        ctx - 2D Tensor of shape (BATCH_SIZE, EMBED_SIZE) (optional)

    # Output
        2D Tensor of shape (BATCH_SIZE, EMBED_SIZE)
    # Usage
        enc = Bidirectional(GRU(EMBED_SIZE,return_sequences=True))(...)
        # with user supplied vector
        ctx = GlobalAveragePooling1D()(enc)
        att = AttentionMV()([enc, ctx])
    """

    def __init__(self, **kwargs):
        super(CustomBiLinear, self).__init__(**kwargs)

    """
    #Keras2.0版本
    def build(self, input_shape):
        assert type(input_shape) is list and len(input_shape) == 2
        # W: (EMBED_SIZE, 1)
        # b: (MAX_TIMESTEPS, 1)
        # U: (EMBED_SIZE, MAX_TIMESTEPS)
        self.W = self.add_weight(name="W_{:s}".format(self.name),
                                 shape=(input_shape[0][-1], 1),
                                 initializer="normal")
        self.b = self.add_weight(name="b_{:s}".format(self.name),
                                 shape=(input_shape[0][1], 1),
                                 initializer="zeros")
        self.U = self.add_weight(name="U_{:s}".format(self.name),
                                 shape=(input_shape[0][-1],
                                        input_shape[0][1]),
                                 initializer="normal")
        super(AttentionMV, self).build(input_shape)
    """
    def build(self,input_shape):
        # W: (EMBED_SIZE, EMBED_SIZE)

        assert type(input_shape) is list and len(input_shape)==2

        print('input_size is :',input_shape[0][0], input_shape[0][1],input_shape[0][-1]) #None, 20, 200
        w_value = np.random.normal(size=(input_shape[0][-1],input_shape[0][-1]))
        self.W = K.variable(w_value,name='W_{:s}'.format(self.name))

        print(self.W.get_shape())       #
        self.trainable_weights = [self.W]
        super(CustomBiLinear,self).build(input_shape)

    def call(self, xs, mask=None):
        # input: [x, u]
        # e1: (BATCH_SIZE, MAX_TIMESTEPS, EMBED_SIZE)
        # e2: (BATCH_SIZE,1, EMBED_SIZE)
        # x, c = xs
        #[?,?,200], [200,1,?].
        e1 = xs[0]  
        e2 = xs[1]
        # e2 = K.expand_dims(e2, axis=-2)
        # f = K.transpose(K.batch_dot(e1, K.transpose(K.dot(e2, self.W)), axes=1))
        # print((K.transpose(K.dot(e2, self.W)),axes=1),)
        # f = K.transpose(K.batch_dot(e1, K.transpose(K.dot(e2, self.W)),axes=[2,-1]))
        f = K.tanh(K.transpose(K.batch_dot(e1, K.transpose(K.dot(e2, self.W)),axes=1)))
        # print(e1.get_shape())
        print('return f shape is:',f.get_shape())
        return f
        
        # et: (BATCH_SIZE, MAX_TIMESTEPS),K.squeeze():将下标为axis的一维从张量中移除
        # et = K.dot(c, self.U) + K.dot(x, self.W)
        # et = K.dot(c,self.U)+K.squeeze(K.dot(x,self.W)+self.b,axis=-1)
        # print('et size is :',et.get_shape())
        # # at: (BATCH_SIZE, MAX_TIMESTEPS)
        # at = K.softmax(et)
        # if mask is not None and mask[0] is not None:
        #     at *= K.cast(mask, K.floatx())
        # # ot: (BATCH_SIZE, MAX_TIMESTEPS, EMBED_SIZE)
        # atx = K.expand_dims(at, axis=-1)
        # ot = atx * x
        # # output: (BATCH_SIZE, EMBED_SIZE)
        # return K.sum(ot, axis=1)
        #return K.sum(ot,axis=0)
        

    def compute_mask(self, input, input_mask=None):
        # do not pass the mask to the next layers
        return None


    def compute_output_shape(self, input_shape):
    # def get_output_shape_for(self,input_shape):
        # output shape: (BATCH_SIZE, EMBED_SIZE)

        return (input_shape[0][0], input_shape[0][-1])


    def get_config(self):
        return super(CustomBiLinear, self).get_config()
