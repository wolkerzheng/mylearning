# -*- coding: utf-8 -*-
__author__ = 'Administrator'
import gensim
import numpy as np 
import sys
def loadWord2Vec(w2vfilepath='./embedding/w2v_model/model/w2v.vector'):
	
	# model = gensim.models.Word2Vec.load(w2vfilepath)
	word2id={"PAD": 0}
	with  open(w2vfilepath,'rb') as f:
		nums, ran = f.readline().strip().split()
		embedding_weight = np.zeros((int(nums)+2, int(ran)))	#(240000+,100)
		# word_dic = dict()
		for i in range(int(nums)):
			line = f.readline().strip().split()
			word, vec = line[0], line[1:]
			vec = list(map(float, vec))
			embedding_weight[i+1, :] = vec
			word2id[word] = i+1
		word2id['<unk>'] = int(nums)+1
		embedding_weight[int(nums)+1,:]  = np.zeros(int(ran))
	print(embedding_weight.shape)
	id2word ={v:k for k,v in word2id.items()}
	return word2id,embedding_weight
	# print type(model)

def loadw2c_200dim(filename = './embedding/w2v_model/model/tieba_word2vector_model_200'):
    model = gensim.models.Word2Vec.load(filename)
    word_vectors = model.wv
    print(word_vectors,type(word_vectors))

    Clients_vectors = np.array([model[word] for word in (model.wv.vocab)])
    # print(Clients_vectors,Clients_vectors.shape)    # (245099, 200)
    embedding_weight = np.zeros((245099+2, 200))	#(240000+,100)
    word2id={"PAD": 0}
    for word in (model.wv.vocab):

        word2id[word] = len(word2id)
        embedding_weight[len(word2id)-1] = np.array(model[word])
    # embedding_weight[int(nums)+1,:]  = np.zeros(int(ran))
    embedding_weight[len(word2id),:]  = embedding_weight.mean(axis=0)
    word2id['<unk>'] = len(word2id)

    print(embedding_weight.shape)
    # print(embedding_weight[len(word2id)-1])
    # id2word ={v:k for k,v in word2id.items()}
    return word2id,embedding_weight
	# print type(model)

if __name__ == '__main__':

    w2vfilepath = './embedding/w2v_model/model/w2v.vector'

    # loadWord2Vec(w2vfilepath)
    loadw2c_200dim()