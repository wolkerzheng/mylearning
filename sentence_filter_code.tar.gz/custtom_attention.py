#encoding=utf8
from keras import backend as K
from keras.engine.topology import Layer
#from keras.layers.merge import add,average,concatenate,maximum,multiply
import numpy as np
class AttentionMV(Layer):

    """
    Keras layer to compute an attention vector on an incoming matrix
    and a user provided context vector.

    # Input
        enc - 3D Tensor of shape (BATCH_SIZE, MAX_TIMESTEPS, EMBED_SIZE)
        ctx - 2D Tensor of shape (BATCH_SIZE, EMBED_SIZE) (optional)

    # Output
        2D Tensor of shape (BATCH_SIZE, EMBED_SIZE)
    # Usage
        enc = Bidirectional(GRU(EMBED_SIZE,return_sequences=True))(...)
        # with user supplied vector
        ctx = GlobalAveragePooling1D()(enc)
        att = AttentionMV()([enc, ctx])

    """

    def __init__(self, **kwargs):
        super(AttentionMV, self).__init__(**kwargs)

    """
    #Keras2.0版本
    def build(self, input_shape):
        assert type(input_shape) is list and len(input_shape) == 2
        # W: (EMBED_SIZE, 1)
        # b: (MAX_TIMESTEPS, 1)
        # U: (EMBED_SIZE, MAX_TIMESTEPS)
        self.W = self.add_weight(name="W_{:s}".format(self.name),
                                 shape=(input_shape[0][-1], 1),
                                 initializer="normal")
        self.b = self.add_weight(name="b_{:s}".format(self.name),
                                 shape=(input_shape[0][1], 1),
                                 initializer="zeros")
        self.U = self.add_weight(name="U_{:s}".format(self.name),
                                 shape=(input_shape[0][-1],
                                        input_shape[0][1]),
                                 initializer="normal")
        super(AttentionMV, self).build(input_shape)
    """
    def build(self,input_shape):
        # W: (EMBED_SIZE, 1)
        # b: (MAX_TIMESTEPS, 1)
        # U: (EMBED_SIZE, MAX_TIMESTEPS)
        assert type(input_shape) is list and len(input_shape)==2

        w_value = np.random.normal(size=(input_shape[0][-1],1))
        self.W = K.variable(w_value,name='W_{:s}'.format(self.name))
        b_value = np.zeros((input_shape[0][1],1))
        self.b = K.variable(b_value,name='b_{:s}'.format(self.name))
        u_value = np.random.normal(size=(input_shape[0][-1],input_shape[0][1]))
        self.U = K.variable(u_value,name='U_{:s}'.format(self.name))

        print(self.W.get_shape())
        self.trainable_weights = [self.W,self.U,self.b]
        super(AttentionMV,self).build(input_shape)

    def call(self, xs, mask=None):
        # input: [x, u]
        # x: (BATCH_SIZE, MAX_TIMESTEPS, EMBED_SIZE)
        # u: (BATCH_SIZE, EMBED_SIZE)
        x, c = xs
        print(x.get_shape())
        print('c shape is:',c.get_shape())
        # et: (BATCH_SIZE, MAX_TIMESTEPS),K.squeeze():将下标为axis的一维从张量中移除
        # et = K.dot(c, self.U) + K.dot(x, self.W)
        et = K.dot(c,self.U)+K.squeeze(K.dot(x,self.W)+self.b,axis=-1)
        print('et size is :',et.get_shape())
        # at: (BATCH_SIZE, MAX_TIMESTEPS)
        at = K.softmax(et)
        if mask is not None and mask[0] is not None:
            at *= K.cast(mask, K.floatx())
        # ot: (BATCH_SIZE, MAX_TIMESTEPS, EMBED_SIZE)
        atx = K.expand_dims(at, axis=-1)
        ot = atx * x
        # output: (BATCH_SIZE, EMBED_SIZE)
        return K.sum(ot, axis=1)
        #return K.sum(ot,axis=0)


    def compute_mask(self, input, input_mask=None):
        # do not pass the mask to the next layers
        return None


    def compute_output_shape(self, input_shape):
    # def get_output_shape_for(self,input_shape):
        # output shape: (BATCH_SIZE, EMBED_SIZE)
        return (input_shape[0][0], input_shape[0][-1])


    def get_config(self):
        return super(AttentionMV, self).get_config()
