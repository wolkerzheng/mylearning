# -*- coding: utf-8 -*-

from keras import backend as K
from keras.layers import Input,Merge,merge
from keras.layers.core import Dense,Dropout
from keras.layers.embeddings import Embedding
from keras.layers.recurrent import GRU,LSTM
from keras.layers.wrappers import TimeDistributed,Bidirectional
from keras.layers import GlobalMaxPool1D,GlobalAveragePooling1D
from keras.models import Model
from keras.optimizers import SGD
from keras.utils import to_categorical
from keras.callbacks import EarlyStopping
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, confusion_matrix
import numpy as np
import pickle
# from pre_build_dictionary import word_dictionary
import generate_data as gd
import sys
import load_tieba_w2v
"""
_________________________________________________________________
Layer (type)                 Output Shape              Param #   
=================================================================
input_1 (InputLayer)         (None, 700)               0         
_________________________________________________________________
embedding_1 (Embedding)      (None, 700, 100)          24510100  
_________________________________________________________________
gru_1 (GRU) |LSTM                 (None, 100)               60300  |80400 
_________________________________________________________________
dense_1 (Dense)              (None, 50)                5050      
_________________________________________________________________
dropout_1 (Dropout)          (None, 50)                0         
_________________________________________________________________
dense_2 (Dense)              (None, 1)                 51        
=================================================================
Total params: 24,575,501
Trainable params: 24,575,501
'Tieba word2vec:'
gru:
 - acc: 0.8975 - val_loss: 0.6117 - val_acc: 0.7354
63720/63720 [==============================] - 1067s 17ms/step
('history', <keras.callbacks.History object at 0x7f418815ead0>)
('Test score:', 0.61447444823427311)
('Test accuracy:', 0.7355775266792216)
LSTM:
0.7300

'Wiki':
gru:
0.64
LSTM:
 0.5732
"""

MAX_WORDS = 700 #每轮对话中最大的词数量

WORD_EMBED_SIZE = 200
SENT_EMBED_SIZE = 100
DOC_EMBED_SIZE = 100

NUM_CLASSES = 2

BATCH_SIZE = 32
NUM_EPOCHS = 10

max_features = 30000
maxlen = 200  # cut texts after this number of words (among top max_features most common words)
batch_size = 32 #64

def load_wiki_tieba():
	word2id={"PAD": 0}
	with  open('./embedding/wiki.zh.text.vector','rb') as f:
		nums, ran = f.readline().strip().split()
		embedding_weight = np.zeros((int(nums)+1, int(ran)))	#(125605,200)

		# word_dic = dict()
		for i in range(int(nums)):
			line = f.readline().strip().split()
			word, vec = line[0], line[1:]
			vec = list(map(float, vec))
			embedding_weight[i+1, :] = vec
			word2id[word] = i+1
	# word2id['PAD'] = int(nums)
	# embedding_weight[int(nums),:]  = np.zeros(int(ran))
	id2word ={v:k for k,v in word2id.items()}
	global WORD_EMBED_SIZE
	WORD_EMBED_SIZE = 200
	return word2id,embedding_weight
def pad_or_truncate(xs, maxlen):
	    if len(xs) > maxlen:
	        xs = xs[len(xs) - maxlen:]
	    elif len(xs) < maxlen:
	        xs = ["PAD"] * (maxlen - len(xs)) + xs
	    return xs

def datagen(X,Y,batch_size=BATCH_SIZE):
	while True:
		num_recs = X.shape[0]
		indices = np.random.permutation(np.arange(num_recs))
		num_batches = num_recs//batch_size

		for bid in range(num_batches):
			batch_ids = indices[bid*batch_size:(bid+1)*batch_size]
			# xbatfrom sklearn.metrics import accuracy_score, confusion_matrixch = np.zeros((batch_size,MAX_SENTS,MAX_WORDS))
			xbatch = X[batch_ids,:]
			ybatch = Y[batch_ids,:]
			yield xbatch,ybatch

def train(mode='GRU',w2vec_mode = 'TB',DIM=200):
# word2id = {"PAD": 0, "UNK": 1}
    if w2vec_mode == 'TB':
        if DIM == 100:
            word2id,embedding_weight = load_tieba_w2v.loadWord2Vec('./embedding/w2v_model/model/w2v.vector')
        else:
            word2id,embedding_weight = load_tieba_w2v.loadw2c_200dim()
    else:
        word2id,embedding_weight = load_wiki_tieba()
    vocab_size = len(word2id)
    print(type(embedding_weight))	#'numpy.ndarray'
    # print(type(embedding_weight.items()[0]))

    positve_data,pos_y = gd.generateNegitivedata()		#生成带负例的训练数据，label为1的表示为噪音数据
    negtive_data,neg_y = gd.generatePostitivedata()
    print('loaded data...')

	# positive_data = word_dict.pad_transform(positve_data,maxlen)
	# negtive_data = word_dict.pad_transform(negtive_data,maxlen)

    x = np.concatenate((positve_data,negtive_data),axis = 0)
    y = np.concatenate((np.ones((len(positve_data), 1)), np.zeros((len(negtive_data), 1))), axis=0)


    X = np.zeros((len(x),MAX_WORDS))
    for docid,sents in enumerate(x):
        sent = []
        for ss in sents:
            sent.extend(ss.strip().split('/'))
        words = pad_or_truncate(sent, MAX_WORDS)
        # words = sent.strip().split('/')
        for wid, word in enumerate(words):
            try:
                word_id = word2id[word]
            except KeyError:
                word_id = word2id['<unk>']
            X[docid, wid] = word_id
    # docid2mat[int(rec_id)] = M
    print(X.shape)		#(212399, 20, 70)
    # Y =
    x_tv, x_test, y_tv, y_test = train_test_split(X, y, test_size=0.3)
    x_train,x_val,y_train,y_val = train_test_split(x_tv,y_tv,train_size=0.9)
    print('Build model...')
    print('data is :',len(x),len(y))	#212399

    # docid2mat = {}
    # ftext = open(DOCSIM_TEXTS, "rb")
    global max_features
    max_features = max(max_features,vocab_size)

    sent_in = Input(shape=(MAX_WORDS,), dtype="int32")

    sent_emb = Embedding(input_dim=max_features,
                           output_dim=WORD_EMBED_SIZE,
                           weights=[embedding_weight],
                            mask_zero=True,trainable=True)(sent_in)

    if mode=='GRU':
        sent_enc = GRU(SENT_EMBED_SIZE,return_sequences=False)(sent_emb)
    elif mode=='LSTM':
        sent_enc = LSTM(SENT_EMBED_SIZE,return_sequences=False)(sent_emb)

    fc1 = Dense(50, activation="relu")(sent_enc)
    fc2_dropout = Dropout(0.2)(fc1)
    doc_pred = Dense(1, activation="sigmoid")(fc2_dropout)

    sent_model = Model(inputs=sent_in, outputs=doc_pred)
    sent_model.summary()


    sent_model.compile(loss="binary_crossentropy", optimizer="adam",
                 metrics=["accuracy"])
    early_stopping =EarlyStopping(monitor='val_loss', patience=1)

    hist = sent_model.fit(x_train, y_train,
              batch_size=BATCH_SIZE,
              epochs=NUM_EPOCHS, shuffle=True,
              callbacks=[early_stopping],validation_split=0.2)
    score, acc = sent_model.evaluate(x_test, y_test,batch_size=BATCH_SIZE)


    print('history', hist)
    print('Test score:', score)
    print('Test accuracy:', acc)
    # sent_model.save('simple_gru_tiebavec.h5')

if __name__ == '__main__':
	if len(sys.argv)>1:
		mode = sys.argv[1]
		w2c  = sys.argv[2]
        DIM = sys.argv[3]
	train(mode=mode,w2vec_mode = w2c,DIM=DIM)
