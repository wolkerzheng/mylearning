# -*- coding: utf-8 -*-
import codecs
from keras.models import load_model 
import numpy as np 
import sys
import time
import jieba
from sklearn.metrics import accuracy_score
import load_tieba_w2v
reload(sys)
sys.setdefaultencoding('UTF-8')
"""
多轮对话评估代码文件
"""
def eval(model,filepath,positive_val = 0.50):
	"""
	func:
	评估主函数
	params:
	model:载入的模型
	filepath:评估文件
	positive_val:初始设置阈值，为了过滤多轮对话的多少，值越大，过滤的越少
	"""
	# disModel = load_model(model)
	start_time = time.time()
	disModel = load_model(model)
	# word2id = load_embedding()
	word2id = load_tieba_w2v.loadWord2Vec()[0]
	batch_data = loadevaldata(filepath)
	y = np.array([])
	p = np.array([])
	for eval_data in batch_data:
		x,tmpy = data_transform(eval_data,word2id)
		predictions = disModel.predict_on_batch(x)
		y = np.concatenate([y,tmpy])
		p = np.concatenate([predictions.flatten(),p])
	# print("accuracy score: ",accuracy_score(y, p))
	count = 0
	for i in xrange(len(p)):
		if i%20==0:
			print p[i],y[i]
		if p[i]>positive_val and y[i]==1:
			count+=1
		elif p[i]<positive_val and y[i]==0:
			count+=1
	print('accuracy_score is :',float(count*1.0/len(p)))

	end_time = time.time()
	print('total time is :'+str(end_time-start_time))
	pass

def data_transform(batch_data,word2id,batch_size=32,MAX_SENTS=20,MAX_WORDS=70):
	"""
	func:
	将帖子数据转换成模型的输入格式
	params:
	batch_data:list，中文帖子
	word2id:字典，词语和id的对照
	batch_size: 批量的大小
	MAX_SENTS: 每轮对话设置的最大句子数
	MAX_WORDS: 每句话中设置的最大词语数
	"""
	evalExamples = []
	labels = []

	for eval_data in batch_data:

		e = eval_data.strip().split('\t')

		evalExamples.append(e[0])
		if 0 in map(int,e[1].strip().split('#')):
			labels.append(1)
		else:
			labels.append(0)
		
	x = [ conversation.strip().split('#') for conversation in evalExamples ]
	# print(type(x))
	X = np.zeros((len(batch_data),MAX_SENTS,MAX_WORDS))

	for docid,sents in enumerate(x):
		sents = pad_or_truncate(sents,MAX_SENTS)
		for sid, sent in enumerate(sents):
			seg_list = ' '.join(jieba.cut(sent))
			words = pad_or_truncate(seg_list.strip().split(' '), MAX_WORDS)
			for wid, word in enumerate(words):
				try:
					word_id = word2id[word]
				except KeyError:
					word_id = word2id['<unk>']
				X[docid, sid, wid] = word_id
	return X,labels	

def pad_or_truncate(xs, maxlen):
    if len(xs) > maxlen:
        xs = xs[len(xs) - maxlen:]
    elif len(xs) < maxlen:
        xs = ["PAD"] * (maxlen - len(xs)) + xs
    return xs

def load_embedding(filepath='./embedding/wiki.zh.text.vector'):
	"""
	func:
	载入词向量的词语和id字典
	params:
	filepath:word2vec的字典路径
	"""
	word2id={"PAD": 0}
	with  open(filepath,'rb') as f:
		nums, ran = f.readline().strip().split()
		embedding_weight = np.zeros((int(nums)+1, int(ran)))	#(125605,200)

		# word_dic = dict()
		for i in range(int(nums)):
			line = f.readline().strip().split()
			word, vec = line[0], line[1:]
			vec = list(map(float, vec))
			embedding_weight[i+1, :] = vec
			word2id[word] = i+1
	# word2id['PAD'] = int(nums)
	# embedding_weight[int(nums),:]  = np.zeros(int(ran))
	id2word ={v:k for k,v in word2id.items()}
	return word2id

def loadevaldata(filepath,batch_size=32):
	"""
	func:
		加载评估文件数据
	params:
	filepath:评估文件的路径
	batch_size:批量的大小
	"""
	evalFile = codecs.open(filepath,'rb')
	evaldata = evalFile.readlines()
	totalLine = len(evaldata)
	number_batch = int((totalLine-1)/batch_size)+1

	for batch_num in xrange(number_batch):

		start_index = batch_num * batch_size
		end_index = min((batch_num+1)*batch_size,totalLine)
		yield evaldata[start_index:end_index]

	evalFile.close()


if __name__ == '__main__':

	model = 'model1.h5'
	model = 'discriminate_model.h5'
	filepath = '../../label_data_part2.txt'
	eval(model,filepath)
