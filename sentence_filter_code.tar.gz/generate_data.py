#encoding=utf8
import numpy as np
import os
import re
import random

def generateNegitivedata(filepath='./data/',batch_size = 25):

	noiseCandidate = readNoiseFiles()
	noiseLength = len(noiseCandidate)
	xdata = []
	ytarget = []
	for filename in os.listdir(filepath):
		if re.match(r'.*\.txt',filename):
			txtfile = os.path.join(filepath,filename)
			with open(txtfile,'r') as f:
				lines = f.readlines()
				idx = 0
				for line in lines:
					idx+=1
					# print (line)
					sentences = line.strip().split(';')
					tmp_y = [0 for _ in xrange(len(sentences))]
					tmp_idx = random.randint(1,len(sentences))
					noise_idx = random.randint(0,noiseLength-1)
					sentences.insert(tmp_idx,noiseCandidate[noise_idx])
					tmp_y.insert(tmp_idx,1)
					if len(sentences)!=len(tmp_y):
						# print('dim is wrong!')
						continue
					xdata.append(sentences)
					ytarget.append(tmp_y)

						# print 'process :',idx
	for x,y in zip(xdata,ytarget):
		for xx in x :
			print(xx)
		print(y)
		break
	print(len(xdata))	#109324
	return xdata,ytarget

def generatePostitivedata(filepath='./positive_data/'):
	# noiseCandidate = readNoiseFiles()
	# noiseLength = len(noiseCandidate)
	xdata = []
	ytarget = []
	for filename in os.listdir(filepath):
		if re.match(r'.*\.txt',filename):
			txtfile = os.path.join(filepath,filename)
			with open(txtfile,'r') as f:
				lines = f.readlines()
				idx = 0
				for line in lines:
					idx+=1
					# print (line)
					sentences = line.strip().split(';')
					tmp_y = [0 for _ in xrange(len(sentences))]
					# tmp_idx = random.randint(1,len(sentences))
					# noise_idx = random.randint(0,noiseLength-1)
					# sentences.insert(tmp_idx,noiseCandidate[noise_idx])
					# tmp_y.insert(tmp_idx,1)
					# if len(sentences)!=len(tmp_y):
					# 	# print('dim is wrong!')
					# 	continue
					xdata.append(sentences)
					ytarget.append(tmp_y)

						# print 'process :',idx
	for x,y in zip(xdata,ytarget):
		for xx in x :
			print(xx)
		print(y)
		break
	print(len(xdata))	#103075
	return xdata,ytarget
def readDataFromFile(txtfile):

	noiseData = []

	with open(txtfile,'r') as f:
		lines = f.readlines()
		for line in lines:
			sentences = line.strip().split(';')
			for sent in sentences:
				if len(sent)>10:	#大于10个词的一句话
					noiseData.append(sent)
	# print('噪音句子集合大小：',len(noiseData))
	return noiseData
def readNoiseFiles(filepath='./noise/'):

	noiseCandidate = []

	for filename in os.listdir(filepath):
		if re.match(r'.*\.txt',filename):
			txtfile = os.path.join(filepath,filename)

			data = readDataFromFile(txtfile)

			noiseCandidate.extend(data)
			if(len(noiseCandidate)>=100000):

				break
	print('total noiseCandidate is :',len(noiseCandidate))	#409307
	return noiseCandidate

def datagen(X,Y,docid2mat,batch_size=32):


	pass

if __name__ == '__main__':
	generateNegitivedata()
	generatePostitivedata()
