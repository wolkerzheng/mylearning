# -*- coding: utf-8 -*-

from keras.models import load_model
from keras.models import Model
import numpy as np 
import codecs
import cPickle as pickle 
import sys
reload(sys)
sys.setdefaultencoding('UTF-8')



def predict(dis_model,filter_model,input_path,output_path):





	pass

def pad_or_truncate(xs, maxlen):
    if len(xs) > maxlen:
        xs = xs[len(xs) - maxlen:]
    elif len(xs) < maxlen:
        xs = ["PAD"] * (maxlen - len(xs)) + xs
    return xs

def load_embedding():

	word2id={"PAD": 0}
	with  open('./embedding/wiki.zh.text.vector','rb') as f:
		nums, ran = f.readline().strip().split()
		embedding_weight = np.zeros((int(nums)+1, int(ran)))	#(125605,200)

		# word_dic = dict()
		for i in range(int(nums)):
			line = f.readline().strip().split()
			word, vec = line[0], line[1:]
			vec = list(map(float, vec))
			embedding_weight[i+1, :] = vec
			word2id[word] = i+1
	# word2id['PAD'] = int(nums)
	# embedding_weight[int(nums),:]  = np.zeros(int(ran))
	id2word ={v:k for k,v in word2id.items()}
	return word2id
def read_data_from_file(lines,batch_size=32):

	print('read data')
	totalLine = len(lines)
	number_batch = int((totalLine-1)/batch_size)+1
	batch_data  = []

	for batch_num in xrange(number_batch):
		start_index = batch_num*batch_size
		end_index = min((batch_num+1)*batch_size,totalLine)
		yield lines[start_index:end_index]
	

def data_transform(batch_data,word2id,batch_size=32,MAX_SENTS=20,MAX_WORDS=70):

	x = [ conversation.strip().split('#') for conversation in batch_data ]
	# print(type(x))
	X = np.zeros((len(batch_data),MAX_SENTS,MAX_WORDS))

	for docid,sents in enumerate(x):
		sents = pad_or_truncate(sents,MAX_SENTS)
		for sid, sent in enumerate(sents):
			words = pad_or_truncate(sent.strip().split(' '), MAX_WORDS)
			for wid, word in enumerate(words):
				try:
					word_id = word2id[word]
				except KeyError:
					word_id = word2id['<unk>']
				X[docid, sid, wid] = word_id
	return X
def main(dis_model,filter_model,input_path,output_path,batch_size=32,positive_eva=0.8):
	print('loading model...')
	disModel = load_model(dis_model)
	# filModel = load_model(filter_model)
	output_file = codecs.open(output_path,'wb','utf-8')
	input_file = codecs.open(input_path,'rb')
	lines = input_file.readlines()
	# read_data_from_file(input_file)
	
	word2id = load_embedding() 

	batches_data = read_data_from_file(lines)
	# print('batches_data is :',len(batches_data))
	all_predictions = []
	count = 0
	for x_predict_batch in batches_data:
		count+=1
		if count % 2000==0: print('batch number is :',count)
		x_data = data_transform(x_predict_batch,word2id)
		batch_predictions = disModel.predict_on_batch(x_data)
		# print(batch_predictions.shape,type(batch_predictions))
		
		all_predictions = np.concatenate([all_predictions, batch_predictions.flatten()])
	print(type(all_predictions),len(all_predictions))
	output_number = 0
	for i in range(len(all_predictions)):
		if all_predictions[i] <= positive_eva:
			output_file.write(lines[i]+'\n') 
			output_number+=1
	print('write file\'s number :',output_number)
	output_file.close()
	input_file.close()	
	print('predict end...')
if __name__ == '__main__':
	dis_model = 'model1.h5' 	#sys.argv[1]
	filter_model = 'filter_model2.h5'	# sys.argv[2] #
	input_path = '../../corpus_part4.txt'		#sys.argv[3]
	output_path = '../../output_corpus_part4.txt'			#sys.argv[4]
	# print(dis_model_,input_path,output_path)
	batch_size = 32
	main(dis_model,filter_model,input_path,output_path,batch_size)