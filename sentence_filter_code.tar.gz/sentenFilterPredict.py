# -*- coding: utf-8 -*-

from keras.models import load_model
from keras.models import Model
import numpy as np 
import codecs
import cPickle as pickle 
import sys
reload(sys)
sys.setdefaultencoding('UTF-8')
"""
"""


def loadFilterModel(dis_model='discriminate_model.h5'):

	disModel = load_model(dis_model)
	return disModel

def pad_or_truncate(xs, maxlen):
    """

    :param xs:
    :param maxlen:
    :return:
    """
    if len(xs) > maxlen:
        xs = xs[len(xs) - maxlen:]
    elif len(xs) < maxlen:
        xs = ["PAD"] * (maxlen - len(xs)) + xs
    return xs

def load_embedding(filepath='./embedding/wiki.zh.text.vector'):
    """

    :return:
    """
	word2id={"PAD": 0}
	with  open(filepath,'rb') as f:
		nums, ran = f.readline().strip().split()
		embedding_weight = np.zeros((int(nums)+1, int(ran)))	#(125605,200)

		# word_dic = dict()
		for i in range(int(nums)):
			line = f.readline().strip().split()
			word, vec = line[0], line[1:]
			vec = list(map(float, vec))
			embedding_weight[i+1, :] = vec
			word2id[word] = i+1
	# word2id['PAD'] = int(nums)
	# embedding_weight[int(nums),:]  = np.zeros(int(ran))
	id2word ={v:k for k,v in word2id.items()}
	return word2id
# def read_data_from_file(lines,batch_size=32):

# 	print('read data')
# 	totalLine = len(lines)
# 	number_batch = int((totalLine-1)/batch_size)+1
# 	batch_data  = []

# 	for batch_num in xrange(number_batch):
# 		start_index = batch_num*batch_size
# 		end_index = min((batch_num+1)*batch_size,totalLine)
# 		yield lines[start_index:end_index]
	

def data_transform(data,word2id,MAX_SENTS=20,MAX_WORDS=70):

	# x = [ conversation.strip().split('\t') for conversation in batch_data ]
	# print(type(x))
	X = np.zeros((1,MAX_SENTS,MAX_WORDS))

	for docid,sents in enumerate(data):
		sents = pad_or_truncate(sents,MAX_SENTS)
		for sid, sent in enumerate(sents):
			words = pad_or_truncate(sent.strip().split(' '), MAX_WORDS)
			for wid, word in enumerate(words):
				try:
					word_id = word2id[word]
				except KeyError:
					word_id = word2id['<unk>']
				X[docid, sid, wid] = word_id
	return X

def mypredict(conver,disModel,word2id,batch_size=32,positive_eva=0.8):
	# print('loading model...')
	# disModel = load_model(dis_model)
	# disModel = loadFilterModel()
	
	# word2id = load_embedding() 

	
	x_data = data_transform(conver,word2id)
	y = disModel.predict(x_data)
	# print('predict end...')
	return y
def eval_conversation_filter(conversation,disModel,word2id,positive_eva=0.8):
	"""
	conversation:每轮对话内容
	disModel:判别模型，loadFilterModel()函数中加载
	word2id:词向量对应的字典表，load_embedding()函数中加载
	"""
	y = mypredict(conversation,disModel,word2id)
	if y>positive_eva:
		return False
	else:
		return True

if __name__ == '__main__':
	# dis_model = 'model1.h5' 	#sys.argv[1]
	# filter_model = 'filter_model2.h5'	# sys.argv[2] #
	# input_path = '../../corpus_part4.txt'		#sys.argv[3]
	# output_path = '../../output_corpus_part4.txt'			#sys.argv[4]
	# # print(dis_model_,input_path,output_path)
	# batch_size = 32
	# positive_eva = 0.8
	# mypredict(dis_model,filter_model,input_path,output_path,batch_size,positive_eva)
	pass